package com.ynu.stocknewsanalysis.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.ynu.stocknewsanalysis.repository.AssetRepository;

public class TradeViewModel extends AndroidViewModel {
    private AssetRepository repository;
    
    private MutableLiveData<Long> userBalance = new MutableLiveData<>();
    private MutableLiveData<Boolean> orderSuccessStatus = new MutableLiveData<>();
    private MutableLiveData<Integer> sentimentScore = new MutableLiveData<>(); // 파이썬 모듈 연동 감성 점수

    public TradeViewModel(@NonNull Application application) {
        super(application);
        repository = new AssetRepository(application);
        // 초기 자산 로드 (가상 유저 학번 세션 할당)
        userBalance.setValue(repository.getBalance("22220926"));
        sentimentScore.setValue(78); // 뉴스 감성 점수 초기 예시 데이터 (긍정 기사 비중 78%)
    }

    public LiveData<Long> getUserBalance() { return userBalance; }
    public LiveData<Boolean> getOrderSuccessStatus() { return orderSuccessStatus; }
    public LiveData<Integer> getSentimentScore() { return sentimentScore; }

    public void executeBuyOrder(String stockCode, int qty, long currentPrice) {
        String userId = "22220926";
        long totalCost = currentPrice * qty;

        if (repository.checkBalance(userId, totalCost)) {
            boolean result = repository.executeOrder(userId, stockCode, qty, currentPrice, true);
            if (result) {
                userBalance.setValue(repository.getBalance(userId));
                orderSuccessStatus.setValue(true);
            } else {
                orderSuccessStatus.setValue(false);
            }
        } else {
            orderSuccessStatus.setValue(false); // 잔고 부족 실패 처리
        }
    }
}