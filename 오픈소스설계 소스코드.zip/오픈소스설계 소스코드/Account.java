package com.ynu.stocknewsanalysis.model;

import java.io.Serializable;

public class Account implements Serializable {
    private String userId;
    private String password;
    private long balance; // 모의 투자 예수금 잔고

    public Account(String userId, String password, long balance) {
        this.userId = userId;
        this.password = password;
        this.balance = balance;
    }

    public String getUserId() { return userId; }
    public String getPassword() { return password; }
    public long getBalance() { return balance; }
    
    public void setBalance(long balance) { this.balance = balance; }
}