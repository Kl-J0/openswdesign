package com.ynu.stocknewsanalysis.repository;

import android.content.Context;
import com.ynu.stocknewsanalysis.model.Account;
import com.ynu.stocknewsanalysis.model.StockVirtualServer;

public class AssetRepository {
    private StockVirtualServer virtualServer;

    public AssetRepository(Context context) {
        this.virtualServer = StockVirtualServer.getInstance(context);
    }

    public long getBalance(String userId) {
        Account account = virtualServer.getAccount(userId);
        return (account != null) ? account.getBalance() : 0L;
    }

    public boolean checkBalance(String userId, long requiredAmount) {
        return getBalance(userId) >= requiredAmount;
    }

    public boolean executeOrder(String userId, String stockCode, int qty, long price, boolean isBuy) {
        return virtualServer.processMatching(userId, stockCode, qty, price, isBuy);
    }
}