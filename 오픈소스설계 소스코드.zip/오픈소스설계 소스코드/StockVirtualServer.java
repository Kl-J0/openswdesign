package com.ynu.stocknewsanalysis.model;

import android.content.Context;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TreeMap;

public class StockVirtualServer {
    private static StockVirtualServer instance;
    private TreeMap<String, Account> accountMap;
    private final String FILE_NAME = "transaction_ledger.txt";
    private File ledgerFile;

    private StockVirtualServer(Context context) {
        accountMap = new TreeMap<>();
        // 테스트용 가상 계정 데이터 초기화 (학번 기준)
        accountMap.put("22220926", new Account("22220926", "password123", 100000000L)); // 1억 원
        
        ledgerFile = new File(context.getFilesDir(), FILE_NAME);
        if (!ledgerFile.exists()) {
            try {
                ledgerFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static synchronized StockVirtualServer getInstance(Context context) {
        if (instance == null) {
            instance = new StockVirtualServer(context.getApplicationContext());
        }
        return instance;
    }

    public Account getAccount(String userId) {
        return accountMap.get(userId);
    }

    // 매매 체결 프로세서 및 로컬 파일 영구 저장 기능 (Self-Call 구조)
    public boolean processMatching(String userId, String stockCode, int qty, long currentPrice, boolean isBuy) {
        Account account = accountMap.get(userId);
        if (account == null) return false;

        long totalCost = currentPrice * qty;

        if (isBuy) {
            if (account.getBalance() < totalCost) return false; // 잔고 부족 예외
            account.setBalance(account.getBalance() - totalCost);
        } else {
            account.setBalance(account.getBalance() + totalCost);
        }

        // 거래 내역 로컬 파일 원장에 영구 기록 호출
        saveTransactionTXT(userId, stockCode, qty, currentPrice, isBuy ? "BUY" : "SELL");
        return true;
    }

    // 파일 입출력(자바 I/O)을 통한 데이터 무결성 독립체 구현
    private void saveTransactionTXT(String userId, String stockCode, int qty, long price, String type) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ledgerFile, true))) {
            String record = System.currentTimeMillis() + "," + userId + "," + stockCode + "," + type + "," + qty + "," + price;
            bw.write(record);
            bw.newLine();
            bw.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}