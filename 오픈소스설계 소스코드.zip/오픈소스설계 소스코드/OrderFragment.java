package com.ynu.stocknewsanalysis.view;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.ynu.stocknewsanalysis.R;
import com.ynu.stocknewsanalysis.viewmodel.TradeViewModel;

public class OrderFragment extends Fragment {

    private TradeViewModel viewModel;
    private TextView tvBalance, tvSentiment;
    private EditText etStockCode, etQuantity;
    private Button btnBuy;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_order, container, false);

        tvBalance = view.findViewById(R.id.tvBalance);
        tvSentiment = view.findViewById(R.id.tvSentiment);
        etStockCode = view.findViewById(R.id.etStockCode);
        etQuantity = view.findViewById(R.id.etQuantity);
        btnBuy = view.findViewById(R.id.btnBuy);

        // 뷰모델 프로바이더를 통해 MVVM 의존성 수립
        viewModel = new ViewModelProvider(this).get(TradeViewModel.class);

        // LiveData 자동 감지(Observation) 패턴 구현
        viewModel.getUserBalance().observe(getViewLifecycleOwner(), balance -> {
            tvBalance.setText("현재 가상 투자 잔고: " + balance + " 원");
        });

        viewModel.getSentimentScore().observe(getViewLifecycleOwner(), score -> {
            tvSentiment.setText("실시간 뉴스 감성 지수: " + score + " 점 (긍정적 시장 신호)");
        });

        viewModel.getOrderSuccessStatus().observe(getViewLifecycleOwner(), isSuccess -> {
            if (isSuccess) {
                Toast.makeText(getContext(), "가상 매매 주문 체결 완료 및 로컬 원장 파일 백업 성공", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "주문 체결 실패: 잔고 부족 또는 세션 오류", Toast.LENGTH_SHORT).show();
            }
        });

        btnBuy.setOnClickListener(v -> {
            String code = etStockCode.getText().toString().trim();
            int qty = Integer.parseInt(etQuantity.getText().toString().trim());
            long mockPrice = 75000L; // 삼성전자 예시 기준가

            if (!code.isEmpty() && qty > 0) {
                viewModel.executeBuyOrder(code, qty, mockPrice);
            }
        });

        return view;
    }
}